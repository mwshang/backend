'use strict';

var config = {
    default: [
        {desc: '10钻石 售价1元', count:10, price:1, img: 'img/1.png'},
        {desc: '50钻石 售价5元', count:50, price:5, img: 'img/1.png'},
        {desc: '100钻石 售价10元', count:100, price:10, img: 'img/2.png'},
        {desc: '200钻石 售价20元', count:200, price:20, img: 'img/3.png'},
        {desc: '500钻石 售价50元', count:500, price:50, img: 'img/4.png'},
        {desc: '1000钻石 售价100元', count:1000, price:100, img: 'img/5.png'},
        {desc: '10000钻石 售价1000元', count:10000, price:1000, img: 'img/6.png'}
    ]
};
